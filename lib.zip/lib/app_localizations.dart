import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// ─────────────────────────────────────────────
// LANGUAGE NOTIFIER - état global de la langue
// ─────────────────────────────────────────────
class LanguageNotifier extends ValueNotifier<String> {
  static final LanguageNotifier _instance = LanguageNotifier._internal();
  factory LanguageNotifier() => _instance;
  LanguageNotifier._internal() : super('fr');
}

final languageNotifier = LanguageNotifier();

// ─────────────────────────────────────────────
// APP LOCALIZATIONS - chargement des JSON
// ─────────────────────────────────────────────
class AppLocalizations {
  static Map<String, String> _translations = {};
  static String _currentLocale = 'fr';

  static Future<void> load(String locale) async {
    _currentLocale = locale;
    final String jsonString =
        await rootBundle.loadString('assets/i18n/$locale.json');
    final Map<String, dynamic> jsonMap = json.decode(jsonString);
    _translations = jsonMap.map((key, value) => MapEntry(key, value.toString()));
  }

  static String tr(String key) {
    return _translations[key] ?? key;
  }

  static String get currentLocale => _currentLocale;
}

// ─────────────────────────────────────────────
// LANGUAGE SELECTOR WIDGET - drapeaux dans AppBar
// ─────────────────────────────────────────────
class LanguageSelectorWidget extends StatelessWidget {
  const LanguageSelectorWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String>(
      valueListenable: languageNotifier,
      builder: (context, currentLang, _) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _flagButton('fr', '🇫🇷', currentLang),
            _flagButton('en', '🇬🇧', currentLang),
            _flagButton('de', '🇩🇪', currentLang),
            const SizedBox(width: 4),
          ],
        );
      },
    );
  }

  Widget _flagButton(String locale, String flag, String currentLang) {
    final isSelected = locale == currentLang;
    return GestureDetector(
      onTap: () async {
        await AppLocalizations.load(locale);
        languageNotifier.value = locale;
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 2),
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: isSelected ? Colors.white : Colors.transparent,
            width: 2,
          ),
          color: isSelected
              ? Colors.white.withValues(alpha: 0.2)
              : Colors.transparent,
        ),
        child: Text(flag, style: const TextStyle(fontSize: 20)),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// LOCALIZED PAGE MIXIN - à utiliser dans chaque State
// Pour rebuilder la page quand la langue change
// ─────────────────────────────────────────────
mixin LocalizedPage<T extends StatefulWidget> on State<T> {
  @override
  void initState() {
    super.initState();
    languageNotifier.addListener(_onLanguageChanged);
  }

  @override
  void dispose() {
    languageNotifier.removeListener(_onLanguageChanged);
    super.dispose();
  }

  void _onLanguageChanged() {
    if (mounted) setState(() {});
  }

  String tr(String key) => AppLocalizations.tr(key);
}
